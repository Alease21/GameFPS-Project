using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface iRechargeableItem
{
    public void RechargeItem(float rechargeTime);
}
