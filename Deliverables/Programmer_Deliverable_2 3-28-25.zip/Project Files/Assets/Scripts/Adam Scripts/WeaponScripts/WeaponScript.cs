using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class WeaponScript : MonoBehaviour
{
    public WeaponSO weaponSO;
    public GameObject weaponPrefab;
    //public IWeaponBehavior weaponBehavior;
}
