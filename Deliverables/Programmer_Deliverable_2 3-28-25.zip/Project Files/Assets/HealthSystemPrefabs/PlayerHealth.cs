using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerHealth : MonoBehaviour
{
    public int _currhealth;
    public int _maxHealth = 100;
    public TMP_Text healthBarValueText;

    void Start()
    {
        _currhealth = _maxHealth;
    }

    private void FixedUpdate()
    {
        healthBarValueText.text = _currhealth.ToString() + "/" + _maxHealth.ToString();
    }

    // Start is called before the first frame update

    public void TakeDamage (int damage)
    {
        _currhealth -= damage;
    }
}
