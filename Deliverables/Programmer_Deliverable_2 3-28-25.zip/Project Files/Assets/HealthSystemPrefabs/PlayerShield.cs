using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerShield : MonoBehaviour
{
    public int _currShield;
    public int _maxShield = 50;
    public TMP_Text ShieldBarValueText;

    void Start()
    {
        _currShield = _maxShield;
    }

    private void FixedUpdate()
    {
        ShieldBarValueText.text = _currShield.ToString() + "/" + _maxShield.ToString();
    }

    // Start is called before the first frame update

    public void TakeDamage(int damage)
    {
        _currShield -= damage;
    }
}
